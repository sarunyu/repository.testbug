import xbmc
xbmc.executebuiltin('RunAddon(script.hello.spittze)')